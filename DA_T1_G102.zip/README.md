# DA-Proj-22
# Instruções de compilação

Para compilar o programa devemos dirigir-nos à pasta code e correr no terminal: g++ menu.cpp -o menu.<br>
Ao executar no terminal será necessário ter como argumentos ./menu e número de cenário<br>
Exemplo:<br>
./menu 1<br>
Caso o utilizador queira testar os cenários com outros inputs será necessário nas linhas 17 e 18 mudar os paths para os respetivos inputs e recompilar o programa.<br>



var searchData=
[
  ['getcusto_9',['getCusto',['../classCarrinha.html#a2f19e055d9d9a553dafe34c8370ee456',1,'Carrinha']]],
  ['getdurar_10',['getDurar',['../classEncomenda.html#add5cbe106e4f710647f1b9fd8203f7c9',1,'Encomenda']]],
  ['getpeso_11',['getPeso',['../classEncomenda.html#a63057714546d6497cb12718e9c95b533',1,'Encomenda']]],
  ['getpesoatual_12',['getPesoAtual',['../classCarrinha.html#a271493098e607208ab341d0d0f2d71e8',1,'Carrinha']]],
  ['getpesomax_13',['getPesoMax',['../classCarrinha.html#a33f9b7192af99acc17451969eb72097a',1,'Carrinha']]],
  ['getrecomp_14',['getRecomp',['../classEncomenda.html#a37fe748273aaa0a75297a51201724c47',1,'Encomenda']]],
  ['getvol_15',['getVol',['../classEncomenda.html#ab9de470c87920eaff7d7440e7ef82c88',1,'Encomenda']]],
  ['getvolatual_16',['getVolatual',['../classCarrinha.html#ae5a5e8e0003720c839dce779c86caedb',1,'Carrinha']]],
  ['getvolmax_17',['getVolMax',['../classCarrinha.html#a2ea336b16953aeb5886ef5ac24fbb370',1,'Carrinha']]]
];

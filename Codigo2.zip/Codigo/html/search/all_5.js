var searchData=
[
  ['setpesoatual_19',['setPesoAtual',['../classCarrinha.html#abdd612127a4b56a4c36deb0769331a7e',1,'Carrinha']]],
  ['setvolatual_20',['setVolAtual',['../classCarrinha.html#ad4925a6c47df7fdeec0e9a74bad9b4cc',1,'Carrinha']]]
];
